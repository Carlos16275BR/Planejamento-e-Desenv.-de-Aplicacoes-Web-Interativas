// a) Troca de posições
const swap = (vetor, i, j) => {
    [vetor[i], vetor[j]] = [vetor[j], vetor[i]];
};

// b) Embaralhar vetor
const shuffle = (vetor, trocas) => {
    for (let i = 0; i < trocas; i++) {
        const a = Math.floor(Math.random() * vetor.length);
        const b = Math.floor(Math.random() * vetor.length);
        swap(vetor, a, b);
    }
};

// c) Bubble Sort
const bubble_sort = (vetor) => {
    for (let i = 0; i < vetor.length - 1; i++) {
        for (let j = 0; j < vetor.length - 1 - i; j++) {
            if (vetor[j] > vetor[j + 1]) {
                swap(vetor, j, j + 1);
            }
        }
    }
};

// d) Selection Sort
const selection_sort = (vetor) => {
    for (let i = 0; i < vetor.length; i++) {
        let min = i;
        for (let j = i + 1; j < vetor.length; j++) {
            if (vetor[j] < vetor[min]) min = j;
        }
        swap(vetor, i, min);
    }
};

// f) Particionamento para Quick Sort
const particionamento = (vetor, inicio, fim) => {
    const pivot = vetor[fim];
    let i = inicio - 1;
    for (let j = inicio; j < fim; j++) {
        if (vetor[j] < pivot) {
            i++;
            swap(vetor, i, j);
        }
    }
    swap(vetor, i + 1, fim);
    return i + 1;
};

// e) Quick Sort
const quick_sort = (vetor, inicio, fim) => {
    if (inicio < fim) {
        const p = particionamento(vetor, inicio, fim);
        quick_sort(vetor, inicio, p - 1);
        quick_sort(vetor, p + 1, fim);
    }
};
